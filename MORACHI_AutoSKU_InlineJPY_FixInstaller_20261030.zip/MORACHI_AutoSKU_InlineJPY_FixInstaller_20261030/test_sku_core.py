"""Pure tests with fake Cosmos DB: no network and no Production writes."""
import copy
import os
import sys
import types
from pathlib import Path

# SDK stubs permit testing core logic in this isolated archive.
azure = types.ModuleType('azure')
core = types.ModuleType('azure.core')
core.MatchConditions = types.SimpleNamespace(IfNotModified=object())
cosmos = types.ModuleType('azure.cosmos')
exceptions = types.ModuleType('azure.cosmos.exceptions')
class Exists(Exception): pass
exceptions.CosmosResourceExistsError = Exists
sys.modules.update({'azure': azure, 'azure.core':core,
    'azure.cosmos':cosmos, 'azure.cosmos.exceptions':exceptions})

sys.path.insert(0, str(Path(__file__).resolve().parent / 'package' / 'api'))
import morachi_sku_core as s

class NotFound(Exception):
    status_code=404

class FakeContainer:
    def __init__(self, products):
        self.products = copy.deepcopy(products)
        self.counter = None
    def query_items(self, **kwargs):
        return self.products
    def read_item(self, item, partition_key):
        if self.counter is None: raise NotFound()
        return dict(self.counter)
    def create_item(self, body):
        if self.counter is not None: raise Exists()
        self.counter = dict(body, _etag='one')
    def patch_item(self, item, partition_key, patch_operations, **kwargs):
        for op in patch_operations:
            if op['op']=='incr': self.counter['last'] += op['value']
            elif op['op']=='set': self.counter['last'] = op['value']
        return dict(self.counter)

os.environ.update({'COSMOS_URL':'https://morachidb.documents.azure.com:443/',
    'COSMOS_ALLOWED_ACCOUNT':'morachidb', 'COSMOS_DB_NAME':'morachi-db',
    'COSMOS_CONTAINER_NAME':'products'})

ct = FakeContainer([{'id':'p0','variants':[
    {'sku':'SKU-MOR-0239','name':'[01] Pink', 'purchase_price_jpy':638,'cost_vnd':108460,'stock':3},
    {'sku':'SKU-MOR-0240','name':'[02] Red', 'stock':0}]}])
created = s.add_skus_on_create(ct, [{'name':'[03] Clear', 'stock':5}])
assert created == [{'name':'[03] Clear','stock':5,'sku':'SKU-MOR-0241'}], created
assert ct.counter['last']==241
ct.products.append({'id':'p1','variants':created})
updated = s.merge_and_assign_on_update(ct, ct.products[0], [
    {'sku':'SKU-MOR-0239','name':'[01] Rose new name','stock':2},
    {'sku':'SKU-MOR-0240','name':'[02] Red','stock':9},
    {'name':'[04] Orange', 'stock':1}])
assert updated[0]['purchase_price_jpy']==638
assert updated[0]['cost_vnd']==108460
assert updated[0]['stock']==2
assert updated[0]['sku']=='SKU-MOR-0239'
assert updated[1]['sku']=='SKU-MOR-0240'
assert updated[2]['sku']=='SKU-MOR-0242'
# Older UI without SKU: exact unique name keeps original cost.
old_admin = s.merge_and_assign_on_update(ct, ct.products[0], [{'name':'[01] Pink','stock':6}])
assert old_admin[0]['purchase_price_jpy']==638 and old_admin[0]['sku']=='SKU-MOR-0239'
try:
    s.merge_and_assign_on_update(ct, ct.products[0], [{'name':'X', 'sku':'SKU-MOR-0241'}])
except ValueError:
    pass
else:
    raise AssertionError('Foreign SKU injection should be blocked')
try:
    s.add_skus_on_create(ct, [{'name':'New','sku':'SKU-MOR-0239','purchase_price_jpy':100}])
except AssertionError:
    raise
else:
    # A new product must ignore client-supplied privileged data.
    pass
assert s.add_skus_on_create(ct, [{'name':'New','sku':'SKU-MOR-0239','purchase_price_jpy':100}])[0]['sku'].startswith('SKU-MOR-')
print('PASS: numbering; no duplicate; lossless price/cost; rename; legacy UI; foreign SKU blocked')
