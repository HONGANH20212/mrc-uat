MORACHI — Auto SKU + Inline JPY (2026-10-30)
===========================================
Bản vá này gồm 7 file (4 sửa, 3 thêm):
  - api/function_app.py                      (sửa bằng installer)
  - admin/admin.js                          (sửa bằng installer)
  - admin/sku-mobile.html                   (sửa bằng installer)
  - staticwebapp.config.json                (sửa bằng installer)
  - api/morachi_sku_core.py                 (mới)
  - api/morachi_sku_api.py                  (mới)
  - admin/sku-price-inline.js               (mới)

Tính năng:
  * POST /api/products: tự cấp SKU-MOR-xxxx cho mỗi phân loại mới.
  * PUT /api/products/{id}: giữ SKU, giá JPY, giá vốn, ngưỡng cảnh báo
    với phân loại hiện có; tự cấp SKU cho phân loại bổ sung.
  * Trong /admin/sku-mobile.html có nút Cấp SKU còn thiếu (từng sản phẩm)
    và form nhập Giá nhập JPY; hệ thống tính cost_vnd=JPY*170.
  * SKU sequence lưu bằng một document bộ đếm Cosmos DB, cộng nguyên tử;
    số có thể nhảy nếu việc ghi sản phẩm thất bại, nhưng không tái sử dụng số.
  * Có ETag để từ chối ghi đè khi dữ liệu thay đổi đồng thời.

CÀI THỬ UAT (không tự triển khai Production):
  1. Copy ZIP vào WSL, ví dụ ~/MORACHI_SHOP
  2. Mở Terminal:

     cd ~/MORACHI_SHOP
     unzip -o MORACHI_AutoSKU_InlineJPY_20261030.zip -d /tmp/morachi-sku-jpy
     python3 /tmp/morachi-sku-jpy/MORACHI_AutoSKU_InlineJPY_20261030/install.py ~/MORACHI_SHOP --check

     Nếu CHECK OK:

     python3 /tmp/morachi-sku-jpy/MORACHI_AutoSKU_InlineJPY_20261030/install.py ~/MORACHI_SHOP --apply
     source ~/MORACHI_SHOP/api/.venv/bin/activate
     python3 -m py_compile api/function_app.py api/morachi_sku_core.py api/morachi_sku_api.py
     node --check admin/admin.js
     node --check admin/sku-price-inline.js
     git diff --check
     git status --short

  3. Môi trường phải có các Function App setting:
     COSMOS_URL / COSMOS_KEY / COSMOS_DB_NAME=morachi-db
     COSMOS_CONTAINER_NAME=products
     COSMOS_ALLOWED_ACCOUNT=<tên account ĐÚNG của môi trường>
     UAT: mrc-uat ; PROD: morachidb (đối chiếu portal trước khi deploy).
     KHÔNG gửi COSMOS_KEY vào chat hoặc commit vào Git.

  4. Kiểm thử UAT:
     - Thêm 1 sản phẩm với 2 phân loại; xem SKU liên tiếp.
     - Sửa tên 1 phân loại: SKU và giá JPY trước đó phải được giữ.
     - Mở /admin/sku-mobile.html, chọn sản phẩm vừa tạo, nhập 638 JPY;
       kiểm tra cost_vnd=108460 và số tồn/giá bán không đổi.
     - Với Mellow Dew mới nhập bị thiếu SKU: bấm Tạo SKU còn thiếu;
       xác nhận rồi kiểm tra lại trong DB.
     - Đăng xuất/Admin không quyền: endpoint /api/manage/sku/* không được phép ghi.
     - Gửi lại ETag cũ: phải bị từ chối với HTTP 409.

CẢNH BÁO QUAN TRỌNG:
  * API Functions trong mã hiện tại dùng HTTP AuthLevel.ANONYMOUS.
    x-ms-client-principal có thể bị giả mạo nếu Function App được gọi trực tiếp.
    KHÔNG DEPLOY PROD khi endpoint functionapp.azurewebsites.net còn truy cập
    công khai; phải áp dụng Azure networking/access restrictions để chỉ reverse
    proxy tin cậy có thể truy cập và cấu hình bảo vệ role morachiadmin tại SWA.
    Đây là yêu cầu bảo mật còn phải kiểm tra trên hạ tầng Production.
  * Cần đảm bảo backend AZURE FUNCTION THỰC TẾ đã deploy cùng mã; push Static
    Web Apps frontend không đảm bảo deploy backend riêng Morachi-Func.
  * Installer chỉ hỗ trợ những source chứa đúng các marker đã kiểm tra.
    Nếu source khác version, sẽ STOP chứ không cố ghi đè.
  * Chưa thử kết nối hay thay đổi Cosmos DB Production.
  * Không commit hoặc push _backup_sku_jpy/ hoặc .pyc.

ROLLBACK:
  * Installer tạo thư mục <project>/_backup_sku_jpy/<timestamp>/.
  * Restore 4 file đã sửa từ bản backup và xóa 3 file mới nếu cần.
  * Không tự xóa SKU hoặc giá đã ghi vào Cosmos DB khi rollback code.

KIỂM THỬ TĨNH CÓ THỂ CHẠY KHÔNG CẦN AZURE:
  python3 /tmp/morachi-sku-jpy/MORACHI_AutoSKU_InlineJPY_20261030/test_sku_core.py
